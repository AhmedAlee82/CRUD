const cors = require("cors");
const express = require("express");

const app = express();

app.use(cors()); 


app.use(express.json());

app.use(express.urlencoded({
  extended:true
}))

const personData=[];

port=3000;

app.listen(port,()=>{
  console.log(`Successfully connected to ${port}`);
});

//POST Api

app.post("/api/add_person",(req,res)=>{
  
  console.log("Result",req.body);
  const pdata ={
    "id":personData.length+1,
    "pname":req.body.pname,
    "prollno":req.body.prollno,
    "page":req.body.page,
  }

  personData.push(pdata);
  console.log("final RESULT",pdata);

  res.status(200).send({
    
    "Status_code":200,
    "Message":"Person Data Is Added Successfully",
    "person":pdata
  }
  );
})