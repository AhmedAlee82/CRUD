

import 'package:flutter/material.dart';
import 'package:frontends/HomePage.dart';

void main(){
  runApp(MyApp());
}

class MyApp extends StatelessWidget{
  @override
  Widget build(Object context) {
     return MaterialApp(
      title: "AxoonSolution Task",

      home: Homepage(),
     );
  }
  
}