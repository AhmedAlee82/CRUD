class Person{
  
  final String? name;
  final String? rollno;
  final String? age;

  Person(
    {this.name,this.rollno,this.age}
    );
}