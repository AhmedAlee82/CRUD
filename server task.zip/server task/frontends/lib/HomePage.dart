import 'package:flutter/material.dart';
import 'package:frontends/create.dart';

class Homepage extends StatefulWidget {
  HomePageState createState() {
    return HomePageState();
  }
}

class HomePageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
            Container(
              height: MediaQuery.of(context).size.height,
              margin: EdgeInsets.symmetric(vertical: 60, horizontal: 40),
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                      colors: [Colors.lightBlueAccent, Colors.pinkAccent])),
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton.icon(
                      
                      onPressed: () {
                        Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => createScreen()));
                      },
                      icon: Icon(Icons.create),
                      label: Text("CREATE")),
                  Padding(padding: EdgeInsets.only(top: 20)),
                  ElevatedButton.icon(
                      onPressed: () {},
                      icon: Icon(Icons.read_more_rounded),
                      label: Text("READ")),
                  Padding(padding: EdgeInsets.only(top: 20)),
                  ElevatedButton.icon(
                      onPressed: () {},
                      icon: Icon(Icons.update),
                      label: Text("UPDATE")),
                  Padding(padding: EdgeInsets.only(top: 20)),
                  ElevatedButton.icon(
                      onPressed: () {},
                      icon: Icon(Icons.delete),
                      label: Text("DELETE")),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
