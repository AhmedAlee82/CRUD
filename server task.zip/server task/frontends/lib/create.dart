import 'package:flutter/material.dart';

import 'services/Api.dart';


class createScreen extends StatefulWidget {
  CreatePageState createState() {
    return CreatePageState();
  }
}

class CreatePageState extends State<createScreen> {
  var nameController = TextEditingController();
  var rollnoController = TextEditingController();
  var ageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
            Container(
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [Colors.lightBlueAccent, Colors.pinkAccent])),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: EdgeInsets.only(top: 20),
                  child: Text(
                    "CREATE",
                    style: TextStyle(
                        color: Colors.white70,
                        fontSize: 32,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 60, horizontal: 40),
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white30),
            ),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.only(right: 70, left: 70),
                    child: TextField(
                      controller: nameController,
                      decoration: InputDecoration(
                        hintText: "Enter Your Name",
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 70, left: 70),
                    child: TextField(
                      controller: rollnoController,
                      decoration: InputDecoration(
                        hintText: "Enter Roll No",
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(right: 70, left: 70),
                    child: TextField(
                      controller: ageController,
                      decoration: InputDecoration(
                        hintText: "Enter Age",
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  ElevatedButton(onPressed: () {
                    var data={
                      "pname":nameController.text,
                      "prollno":rollnoController.text,
                      "page":ageController.text,

                      
                    };
                          Api.addPerson(data);
                  }, child: Text("Submit")),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
