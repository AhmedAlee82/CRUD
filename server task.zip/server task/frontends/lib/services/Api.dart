import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';


class Api{

  static const baseUrl="http://192.168.200.78:3000/api/";

  static addPerson(Map pdata) async{
    print(pdata);
    var url= Uri.parse(baseUrl+"add_person");

  try{
        final res=await http.post(url,body: pdata);

        if(res.statusCode==200){
          var data = jsonDecode(res.body.toString());
          print(data);
      
    }else{
      print("FAILED to Upload DATA");
    }
  }catch(e){
    debugPrint(e.toString());
  }

  }
}