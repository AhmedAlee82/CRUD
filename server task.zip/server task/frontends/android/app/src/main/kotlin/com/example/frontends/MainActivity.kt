package com.example.frontends

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
